def pow(a,b):
	return a ^ b

def pi():
    return 3.141592

def e():
    return 2.718281

def sqrt(a):
    return native rtl_math(0, a)

def sin(a):
    return native rtl_math(1, a)

def cos(a):
    return native rtl_math(2, a)

def tan(a):
    return native rtl_math(3, a)

def asin(a):
    return native rtl_math(4, a)

def acos(a):
    return native rtl_math(5, a)

def atan(a):
    return native rtl_math(6, a)

def sinh(a):
    return native rtl_math(7, a)

def cosh(a):
    return native rtl_math(8, a)

def tanh(a):
    return native rtl_math(9, a)

def floor(a):
    return native rtl_math(10, a)

def ceil(a):
    return native rtl_math(11, a)

def log(a):
    return native rtl_math(12, a)

def log10(a):
    return native rtl_math(13, a)
