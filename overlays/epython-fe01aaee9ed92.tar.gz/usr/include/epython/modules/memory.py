def free(a):
    native rtl_free(a)

def gc():
    native rtl_gc()
